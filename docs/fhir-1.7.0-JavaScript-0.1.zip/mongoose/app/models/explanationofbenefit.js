// Copyright (c) 2011+, HL7, Inc & The MITRE Corporation
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
// 
//     * Redistributions of source code must retain the above copyright notice, this 
//       list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright notice, 
//       this list of conditions and the following disclaimer in the documentation 
//       and/or other materials provided with the distribution.
//     * Neither the name of HL7 nor the names of its contributors may be used to 
//       endorse or promote products derived from this software without specific 
//       prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
// POSSIBILITY OF SUCH DAMAGE.

var mongoose = require('mongoose');

var ExplanationOfBenefitSchema = new mongoose.Schema({
    identifier: [{
        use: String,
        label: String,
        system: String,
        value: String
    }],
    ruleset: {
        system: String,
        code: String,
        display: String
    },
    originalRuleset: {
        system: String,
        code: String,
        display: String
    },
    status: String,
    fhirType: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    subType: [{
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    }],
    patient: {
    },
    billablePeriod: {
    },
    created: Date,
    enterer: {
    },
    insurer: {
    },
    provider: {
    },
    organization: {
    },
    referral: {
    },
    facility: {
    },
    claim: {
    },
    claimResponse: {
    },
    outcome: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    disposition: String,
    related: [{
        claim: {
        },
        relationship: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        reference: {
            use: String,
            label: String,
            system: String,
            value: String
        }
    }],
    prescription: {
    },
    originalPrescription: {
    },
    payee: {
        fhirType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        resourceType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        partyIdentifier: {
            use: String,
            label: String,
            system: String,
            value: String
        },
        partyReference: {
        }
    },
    information: [{
        category: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        code: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        timingDate: Date,
        timingPeriod: {
        },
        valueString: String,
        valueQuantity: {
            value: String,
            units: String,
            system: String,
            code: String
        },
        valueAttachment: {
        },
        valueReference: {
        },
        reason: {
            system: String,
            code: String,
            display: String
        }
    }],
    careTeam: [{
        sequence: {
        },
        provider: {
        },
        responsible: Boolean,
        role: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        qualification: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }
    }],
    diagnosis: [{
        sequence: {
        },
        diagnosisCodeableConcept: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        diagnosisReference: {
        },
        fhirType: [{
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }],
        packageCode: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }
    }],
    procedure: [{
        sequence: {
        },
        date: Date,
        procedureCodeableConcept: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        procedureReference: {
        }
    }],
    precedence: {
    },
    insurance: {
        coverage: {
        },
        preAuthRef: String,
    },
    accident: {
        date: Date,
        fhirType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        locationAddress: {
        },
        locationReference: {
        }
    },
    employmentImpacted: {
    },
    hospitalization: {
    },
    item: [{
        sequence: {
        },
        careTeamLinkId: [{
        }],
        diagnosisLinkId: [{
        }],
        procedureLinkId: [{
        }],
        informationLinkId: [{
        }],
        revenue: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        category: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        service: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        modifier: [{
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }],
        programCode: [{
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }],
        servicedDate: Date,
        servicedPeriod: {
        },
        locationCodeableConcept: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        locationAddress: {
        },
        locationReference: {
        },
        quantity: {
        },
        unitPrice: {
        },
        factor: Number,
        net: {
        },
        udi: [{
        }],
        bodySite: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        subSite: [{
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }],
        noteNumber: [{
        }],
        adjudication: [{
            category: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            reason: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            amount: {
            },
            value: Number,
        }],
        detail: [{
            sequence: {
            },
            fhirType: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            revenue: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            category: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            service: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            modifier: [{
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            }],
            programCode: [{
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            }],
            quantity: {
            },
            unitPrice: {
            },
            factor: Number,
            net: {
            },
            udi: [{
            }],
            noteNumber: [{
            }],
            adjudication: [{
            }],
            subDetail: [{
                sequence: {
                },
                fhirType: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                },
                revenue: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                },
                category: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                },
                service: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                },
                modifier: [{
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                }],
                programCode: [{
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                }],
                quantity: {
                },
                unitPrice: {
                },
                factor: Number,
                net: {
                },
                udi: [{
                }],
                noteNumber: [{
                }],
                adjudication: [{
                }]
            }]
        }],
        prosthesis: {
            initial: Boolean,
            priorDate: Date,
            priorMaterial: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            }
        }
    }],
    addItem: [{
        sequenceLinkId: [{
        }],
        revenue: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        category: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        service: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        modifier: [{
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }],
        fee: {
        },
        noteNumber: [{
        }],
        adjudication: [{
        }],
        detail: [{
            revenue: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            category: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            service: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            modifier: [{
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            }],
            fee: {
            },
            noteNumber: [{
            }],
            adjudication: [{
            }]
        }]
    }],
    totalCost: {
    },
    unallocDeductable: {
    },
    totalBenefit: {
    },
    payment: {
        fhirType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        adjustment: {
        },
        adjustmentReason: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        date: Date,
        amount: {
        },
        identifier: {
            use: String,
            label: String,
            system: String,
            value: String
        }
    },
    form: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    note: [{
        number: {
        },
        fhirType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        text: String,
        language: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }
    }],
    benefitBalance: [{
        category: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        subCategory: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        excluded: Boolean,
        name: String,
        description: String,
        network: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        unit: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        term: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        financial: [{
            fhirType: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            benefitUnsignedInt: {
            },
            benefitString: String,
            benefitMoney: {
            },
            benefitUsedUnsignedInt: {
            },
            benefitUsedMoney: {
            }
        }]
    }]
});

mongoose.model('ExplanationOfBenefit', ExplanationOfBenefitSchema);
