// Copyright (c) 2011+, HL7, Inc & The MITRE Corporation
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
// 
//     * Redistributions of source code must retain the above copyright notice, this 
//       list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright notice, 
//       this list of conditions and the following disclaimer in the documentation 
//       and/or other materials provided with the distribution.
//     * Neither the name of HL7 nor the names of its contributors may be used to 
//       endorse or promote products derived from this software without specific 
//       prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
// POSSIBILITY OF SUCH DAMAGE.

var mongoose = require('mongoose');

var PlanDefinitionSchema = new mongoose.Schema({
    url: String,
    identifier: [{
        use: String,
        label: String,
        system: String,
        value: String
    }],
    version: String,
    name: String,
    title: String,
    fhirType: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    status: String,
    experimental: Boolean,
    date: Date,
    description: {
    },
    purpose: {
    },
    usage: String,
    approvalDate: Date,
    lastReviewDate: Date,
    effectivePeriod: {
    },
    useContext: [{
    }],
    jurisdiction: [{
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    }],
    topic: [{
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    }],
    contributor: [{
    }],
    publisher: String,
    contact: [{
    }],
    copyright: {
    },
    relatedArtifact: [{
    }],
    library: [{
    }],
    actionDefinition: [{
        actionIdentifier: {
            use: String,
            label: String,
            system: String,
            value: String
        },
        label: String,
        title: String,
        description: String,
        textEquivalent: String,
        code: [{
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }],
        documentation: [{
        }],
        triggerDefinition: [{
        }],
        condition: [{
            kind: String,
            description: String,
            language: String,
            expression: String,
        }],
        input: [{
        }],
        output: [{
        }],
        relatedAction: [{
            actionIdentifier: {
                use: String,
                label: String,
                system: String,
                value: String
            },
            relationship: String,
            offsetDuration: {
            },
            offsetRange: {
            }
        }],
        timingDateTime: Date,
        timingPeriod: {
        },
        timingDuration: {
        },
        timingRange: {
        },
        timingTiming: {
        },
        participantType: String,
        fhirType: {
            system: String,
            code: String,
            display: String
        },
        groupingBehavior: String,
        selectionBehavior: String,
        requiredBehavior: String,
        precheckBehavior: String,
        cardinalityBehavior: String,
        activityDefinition: {
        },
        transform: {
        },
        dynamicValue: [{
            description: String,
            path: String,
            language: String,
            expression: String,
        }],
        actionDefinition: [{
        }]
    }]
});

mongoose.model('PlanDefinition', PlanDefinitionSchema);
